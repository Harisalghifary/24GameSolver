File dibagi menjadi 2 front-end, yaitu

1. Front-end 1 : 
	- File bernama frontend1.py
	- Diakses dengan memasukkan perintah 'python frontend1.py' di command line
	- Akan mengeluarkan GUI program

2. Front-end 2 :
	- File bernama frontend2.py
	- Membutuhkan file input dan mengeluarkan file output
	- Diakses dengan memasukkan perintah 'python frontend2.py <file_input> <file_output>'
	- Akan menerima masukan dari file_input dan membuat file baru sesuai nama file_output